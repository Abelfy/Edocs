import { Component } from '@angular/core';

@Component({
  selector: 'edocs-version-page',
  standalone: true,
  imports: [],
  templateUrl: './version-page.component.html',
  styleUrl: './version-page.component.scss'
})
export class VersionPageComponent {

}
